export class User {
    firstName : string;
    lastName : string;
    gender : string;
    contact : number;
    email : string;
    password : string;
    constructor(value){
        Object.assign(this,value);
    }
}

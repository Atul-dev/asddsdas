import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
// import { Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { User } from './users/user';
import { UserService } from './services/user.service';
import { ActivatedRoute, Router, Params } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  
  title = 'demo';
  registerForm : FormGroup;
  // newArray;
  editMode : boolean = false;
  id : number;
  userData : User[] = [];

  constructor(private fb: FormBuilder, private userservice : UserService, private routes:Router,private router:ActivatedRoute){
  }
  ngOnInit() {
    // alert()
    // console.log(this.router.params)
    this.router.params.subscribe((param : Params)=>{
      this.id = +param.id;
      this.editMode = param.id != null;
      this.openForm();
      // alert()
    });
  }
    save(){ 
      this.userservice.addUserData(this.registerForm.value)
    }

    cancel(){
      this.registerForm.reset();
    }
    newUser(event)
    {
      event.preventDefault();
      this.routes.navigate(['userList'],{relativeTo: this.router })
      // console.log(this.routes);
    }
    openForm(){
      if(this.editMode)
      {
        console.log("no")
        const userData = this.userservice.getUserData(this.id);

        this.registerForm = this.fb.group({
        firstName : userData.firstName,
        lastName : userData.lastName,
        gender : userData.gender,
        contact : userData.contact,
        email : userData.email,
        password : userData.password
    });
      }else{
        // console.log("non edit")
        this.registerForm = this.fb.group({
          firstName : '',
          lastName : '',
          gender : '',
          contact : '',
          email : '',
          password : ''
        });
      }
    }
  }
import { Injectable } from '@angular/core';
import { User } from '../users/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userDataLists : User[] = [new User({firstName:'Atul',lastName:'Gupta',gender:'male',contact:123456,email:'atul@gmail.com',paasword:'12345'}),
                            new User({firstName:'Piyush',lastName:'Gupta',gender:'male',contact:654321,email:'piyush@gmail.com',paasword:'54321'})
                          ];

  constructor() { }
  addUserData(userData:any){

    // this.userDataLists.push(new User(userData));
    this.userDataLists.push(userData);
    // console.log(this.userDataLists);
  }

  getUserData(i)
  {
    return this.userDataLists[i];
  }
}
